package com.ejemplo_poo.poo.model;

public class CheckingAccount extends Account {
    private double overdraftLimit;

    public CheckingAccount() {
        super();
    }

    public CheckingAccount(String id, Customer owner, Money balance, double overdraftLimit) {
        super(id, owner, balance);
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public void applyInterest() {

    }

    public boolean withdraw(Money amount) {
        double avaible = getBalance().getAmount() + overdraftLimit;

        if (avaible >= amount.getAmount()) {
            getBalance().setAmount(getBalance().getAmount() - amount.getAmount());
            getTransactions().add(new Transactions("EDR", amount, getId()));

            return true;
        }

        return false;
    }

    public double getOverdraftLimit(){
        return overdraftLimit;
        
    }

    public void setOverdraftLimit(double overdraftLimit){
        this.overdraftLimit = overdraftLimit;
    }
}
